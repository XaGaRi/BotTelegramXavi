from multiprocessing.resource_sharer import stop
import random
from unicodedata import name
from webbrowser import get
from telegram import *
from telegram.ext import * 
import requests
from iso3166 import countries
updater = Updater(token="5700774825:AAHpMX-OkriI3Zc8lM4Bbd3bEP7hi2wt828")
dispatcher = updater.dispatcher

any2022 = "2022"
any2026 = "2026"

'''randomPeopleUrl = "https://thispersondoesnotexist.com/image"
randomPImageUrl = "https://picsum.photos/1200"'''

def selecPais(num):
    paisos = []
    contador=0
    
    for c in countries:
        paisos[contador] = countries.get(name)
        contador+=1


    return paisos[num]


def startCommand(update: Update, context: CallbackContext):
    buttons = [[KeyboardButton(any2022)], [KeyboardButton(any2026)]]
    context.bot.send_message(chat_id=update.effective_chat.id, text="Benvingut, aquest bot diu quina seleccio sera la guanyadora dels proxims mundials", reply_markup=ReplyKeyboardMarkup(buttons))

def repeat(update: Update, context: CallbackContext):
    buttons = [[KeyboardButton(any2022)], [KeyboardButton(any2026)]]
    context.bot.send_message(chat_id=update.effective_chat.id, text="Digues quin any vols veure", reply_markup=ReplyKeyboardMarkup(buttons))

def messageHandler(update: Update, context: CallbackContext):
    aleatori = random.randint(0,205)
    if any2022 in update.message.text:
        context.bot.send_message(chat_id=update.effective_chat.id, text="El guanyador sera "+ selecPais(aleatori))

    if any2026 in update.message.text:
        context.bot.send_message(chat_id=update.effective_chat.id, text="El guanyador sera "+ selecPais(aleatori))

    '''context.bot.sendMediaGroup(chat_id=update.effective_chat.id, media=[InputMediaPhoto(image, caption="")])'''

    buttons = [[InlineKeyboardButton("Vols veure un altre any?", callback_data="repeat")], [InlineKeyboardButton("Vols sortir?", callback_data="surt")]]
    context.bot.send_message(chat_id=update.effective_chat.id, reply_markup=InlineKeyboardMarkup(buttons), text="Que vols fer")

def queryHandler(update: Update, context: CallbackContext):
    query = update.callback_query.data
    update.callback_query.answer()

    global likes, dislikes

    if "repeat" in query:
        repeat()
    
    if "surt" in query:
        stop


dispatcher.add_handler(CommandHandler("start", startCommand))
dispatcher.add_handler(MessageHandler(Filters.text, messageHandler))
dispatcher.add_handler(CallbackQueryHandler(queryHandler))

updater.start_polling()